<?php
echo "<h2> header():- This is a pre-defined function of PHP , header() is work HTTP functions  data sent client or browser by web server
   This is also used set by using location page and redirect.</h2>";
if(isset($_POST['submit']))
{
    $fname=$_POST['fname'];
    $lname=$_POST['lname'];

    echo $fname,$lname;

    header("location:welcome.php");
}

?>


<!DOCTYPE html>
<html>
<head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title>Page Title</title>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <link rel='stylesheet' type='text/css' media='screen' href='main.css'>
    <script src='main.js'></script>
</head>
<body>
<form action="welcome.php" method="post">
<table border="1">
    <tr>
        <td>First Name:<input type="text" name="fname" /></td>
    </tr>
    <tr>
        <td>Last Name:<input type="text" name="lname" /></td>
    </tr>
    <tr>
        <td colspan="2" align="center"><input type="submit" name="submit" value="Submit" /></td>
    </tr>
            
</table>

</form>    
    
</body>
</html> 